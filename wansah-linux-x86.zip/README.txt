Wansah Application

How to run:
chmod +x Wansah-x86_64.AppImage
./Wansah-x86_64.AppImage

Built with Qt6 + AppImage
Platform: Linux x86_64
