import glob
import os
import re
import sys

keep = os.environ.get("W_WIN_DLL", "")
keep_names = {
    name.strip().lower()
    for name in re.findall(r"DLL Name:\s*([^\s]+\.dll)", keep, flags=re.IGNORECASE)
}
if not keep_names:
    keep_names = {
        name.strip().lower()
        for token in re.split(r"[;:\s]+", keep)
        if token.strip().lower().endswith(".dll")
    }

dll_files = glob.glob("**/*.dll", recursive=True)
for dll_path in dll_files:
    dll_name = os.path.basename(dll_path).lower()
    if keep_names and dll_name in keep_names:
        continue
    print("removing " + dll_path)
    try:
        os.remove(dll_path)
    except OSError as exc:
        print(f"failed to remove {dll_path}: {exc}", file=sys.stderr)
